# -*- coding: utf-8 -*-

from odoo import models, fields, api
from odoo.exceptions import ValidationError

class estado_convenio(models.Model):
    _name= 'uprofe.estado_convenio'
    _description = 'Estados de convenio'
    _order = 'name asc'
    
    name= fields.Char(string='Nombre',size=50, required=True)
    sDescripcion=fields.Text(string="Descripción")
    
    #El nombre del estado de convenio debe ser único
    @api.constrains('name')
    def _check_name_unique(self):
        for record in self:
            if self.search_count([("id", "!=", record.id), ("name", "=ilike", record.name.strip())]):
                raise ValidationError("El nombre del estado de convenio debe ser único.")
    
    #El nombre del estado de convenio no puede estar vacío
    @api.constrains('name')
    def _check_name_not_empty(self):
        for record in self:
            if len(record.name.strip()) == 0:
                raise ValidationError("El nombre del estado no puede estar vacío.")
